// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
// See the LICENSE file in the project root for more information.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using Microsoft.ML;
using Microsoft.ML.CommandLine;
using Microsoft.ML.Data;
using Microsoft.ML.EntryPoints;
using Microsoft.ML.Featurizers;
using Microsoft.ML.Internal.Utilities;
using Microsoft.ML.Runtime;
using Microsoft.ML.Transforms;
using Microsoft.Win32.SafeHandles;
using static Microsoft.ML.Featurizers.CommonExtensions;

[assembly: LoadableClass(typeof(L2NormalizeTransformer), null, typeof(SignatureLoadModel),
    L2NormalizeTransformer.UserName, L2NormalizeTransformer.LoaderSignature)]

[assembly: LoadableClass(typeof(IRowMapper), typeof(L2NormalizeTransformer), null, typeof(SignatureLoadRowMapper),
L2NormalizeTransformer.UserName, L2NormalizeTransformer.LoaderSignature)]

[assembly: EntryPointModule(typeof(L2NormalizeEntrypoint))]

namespace Microsoft.ML.Featurizers
{
    public static class L2NormalizeExtensionClass
    {
        public static L2NormalizeEstimator L2NormalizeTransformer(this TransformsCatalog catalog, string outputColumnName, string inputColumnName = null /* Insert additional params here as needed*/)
        {
            var options = new L2NormalizeEstimator.Options
            {
                Columns = new L2NormalizeEstimator.Column[] { new L2NormalizeEstimator.Column() { Name = outputColumnName, Source = inputColumnName ?? outputColumnName } },
                
                /* Codegen: add extra options here as needed */
            };

            return new L2NormalizeEstimator(CatalogUtils.GetEnvironment(catalog), options);
        }

        public static L2NormalizeEstimator L2NormalizeTransformer(this TransformsCatalog catalog, InputOutputColumnPair[] columns /* Insert additional params here as needed*/)
        {
            var options = new L2NormalizeEstimator.Options
            {
                Columns = columns.Select(x => new L2NormalizeEstimator.Column { Name = x.OutputColumnName, Source = x.InputColumnName ?? x.OutputColumnName }).ToArray(),
                
                /* Codegen: add extra options here as needed */
            };

            return new L2NormalizeEstimator(CatalogUtils.GetEnvironment(catalog), options);
        }
    }

    public class L2NormalizeEstimator : IEstimator<L2NormalizeTransformer>
    {
        private Options _options;
        private readonly IHost _host;

        /* Codegen: Add additional needed class members here */

        #region Options

        /* If not one to one need to change this */
        internal sealed class Column : OneToOneColumn
        {
            internal static Column Parse(string str)
            {
                Contracts.AssertNonEmpty(str);

                var res = new Column();
                if (res.TryParse(str))
                    return res;
                return null;
            }

            internal bool TryUnparse(StringBuilder sb)
            {
                Contracts.AssertValue(sb);
                return TryUnparseCore(sb);
            }
        }

        internal sealed class Options: TransformInputBase
        {
            [Argument(ArgumentType.Multiple | ArgumentType.Required, HelpText = "New column definition (optional form: name:src)",
                Name = "Column", ShortName = "col", SortOrder = 1)]
            public Column[] Columns;

            

            /* Codegen: Add additonal options as needed */
        }

        #endregion

        internal L2NormalizeEstimator(IHostEnvironment env, Options options)
        {
            Contracts.CheckValue(env, nameof(env));
            _host = env.Register(nameof(L2NormalizeEstimator));
            Contracts.CheckNonEmpty(options.Columns, nameof(options.Columns));
            /* Codegen: Any other checks for options go here */

            _options = options;
        }

        public L2NormalizeTransformer Fit(IDataView input)
        {
            return new L2NormalizeTransformer(_host, input, _options);
        }

        public SchemaShape GetOutputSchema(SchemaShape inputSchema)
        {
            var columns = inputSchema.ToDictionary(x => x.Name);

            foreach (var column in _options.Columns)
            {
                var inputColumn = columns[column.Source];

                if (!L2NormalizeTransformer.TypedColumn.IsColumnTypeSupported(inputColumn.ItemType.RawType))
                    throw new InvalidOperationException($"Type {inputColumn.ItemType.RawType.ToString()} for column {column.Name} not a supported type.");

                /* Codegen: Do correct schema mapping here */

            }
            return new SchemaShape(columns.Values);
        }
    }

    public sealed class L2NormalizeTransformer : RowToRowTransformerBase, IDisposable
    {
        #region Class data members

        internal const string Summary = ""; /* Insert summary here */
        internal const string UserName = "L2NormalizeTransformer";
        internal const string ShortName = "L2NormalizeTransformer";
        internal const string LoadName = "L2NormalizeTransformer";
        internal const string LoaderSignature = "L2NormalizeTransformer";

        private TypedColumn[] _columns;
        private L2NormalizeEstimator.Options _options;

        #endregion

        internal L2NormalizeTransformer(IHostEnvironment host, IDataView input, L2NormalizeEstimator.Options options) :
            base(host.Register(nameof(L2NormalizeTransformer)))
        {
            var schema = input.Schema;
            _options = options;

            _columns = options.Columns.Select(x => TypedColumn.CreateTypedColumn(x.Name, x.Source, schema[x.Source].Type.RawType.ToString(), this)).ToArray();
            foreach (var column in _columns)
            {
                column.CreateTransformerFromEstimator(input);
            }
        }

        // Factory method for SignatureLoadModel.
        internal L2NormalizeTransformer(IHostEnvironment host, ModelLoadContext ctx) :
            base(host.Register(nameof(L2NormalizeTransformer)))
        {
            Host.CheckValue(ctx, nameof(ctx));
            ctx.CheckAtModel(GetVersionInfo());

            /* Codegen: Edit this format as needed */
            // *** Binary format ***
            // int number of column pairs
            // for each column pair:
            //      string output column  name
            //      string input column name
            //      column type
            //      int length of c++ byte array
            //      byte array from c++

            var columnCount = ctx.Reader.ReadInt32();

            _options = new L2NormalizeEstimator.Options();
            /* Codegen: Load any additional Options members here */

            _columns = new TypedColumn[columnCount];
            for (int i = 0; i < columnCount; i++)
            {
                _columns[i] = TypedColumn.CreateTypedColumn(ctx.Reader.ReadString(), ctx.Reader.ReadString(), ctx.Reader.ReadString(), this);

                // Load the C++ state and create the C++ transformer.
                var dataLength = ctx.Reader.ReadInt32();
                var data = ctx.Reader.ReadByteArray(dataLength);
                _columns[i].CreateTransformerFromSavedData(data);
            }
        }

        // Factory method for SignatureLoadRowMapper.
        private static IRowMapper Create(IHostEnvironment env, ModelLoadContext ctx, DataViewSchema inputSchema)
            => new L2NormalizeTransformer(env, ctx).MakeRowMapper(inputSchema);

        private protected override IRowMapper MakeRowMapper(DataViewSchema schema) => new Mapper(this, schema);

        private static VersionInfo GetVersionInfo()
        {
            /* Codegen: Change these as needed */
            return new VersionInfo(
                modelSignature: "Enter 8 character long name here", /* Codegen: Enter * character name here */
                verWrittenCur: 0x00010001, /* Codegen: Update version numbers as necessary */
                verReadableCur: 0x00010001,
                verWeCanReadBack: 0x00010001,
                loaderSignature: LoaderSignature,
                loaderAssemblyName: typeof(L2NormalizeTransformer).Assembly.FullName);
        }

        private protected override void SaveModel(ModelSaveContext ctx)
        {
            Host.CheckValue(ctx, nameof(ctx));
            ctx.CheckAtModel();
            ctx.SetVersionInfo(GetVersionInfo());

            /* Codegen: Edit this format as needed */
            // *** Binary format ***
            // int number of column pairs
            // for each column pair:
            //      string output column  name
            //      string input column name
            //      column type
            //      int length of c++ byte array
            //      byte array from c++

            ctx.Writer.Write(_columns.Count());

            /* Codegen: Write any _options members needed here */

            foreach (var column in _columns)
            {
                ctx.Writer.Write(column.Name);
                ctx.Writer.Write(column.Source);
                ctx.Writer.Write(column.Type);

                // Save C++ state
                var data = column.CreateTransformerSaveData();
                ctx.Writer.Write(data.Length);
                ctx.Writer.Write(data);
            }
        }

        public void Dispose()
        {
            foreach (var column in _columns)
            {
                column.Dispose();
            }
        }

        #region ColumnInfo

        #region BaseClass

        internal abstract class TypedColumn : IDisposable
        {
            internal readonly string Name;
            internal readonly string Source;
            internal readonly string Type;

            /* Codegen: Fill in supported types */
            private static readonly Type[] _supportedTypes = new Type[] { typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1), typeof(TODO1) };

            /* Codegen: Any other needed members */

            internal TypedColumn(string name, string source, string type)
            {
                Name = name;
                Source = source;
                Type = type;
            }

            internal abstract void CreateTransformerFromEstimator(IDataView input);
            private protected abstract unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize);
            private protected abstract bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle);
            public abstract void Dispose();

            public abstract Type ReturnType();

            internal byte[] CreateTransformerSaveData()
            {

                var success = CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle);
                if (!success)
                    throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                using (var savedDataHandle = new SaveDataSafeHandle(buffer, bufferSize))
                {
                    byte[] savedData = new byte[bufferSize.ToInt32()];
                    Marshal.Copy(buffer, savedData, 0, savedData.Length);
                    return savedData;
                }
            }

            internal unsafe void CreateTransformerFromSavedData(byte[] data)
            {
                fixed (byte* rawData = data)
                {
                    IntPtr dataSize = new IntPtr(data.Count());
                    CreateTransformerFromSavedDataHelper(rawData, dataSize);
                }
            }

            internal static bool IsColumnTypeSupported(Type type)
            {
                return _supportedTypes.Contains(type);
            }

            internal static TypedColumn CreateTypedColumn(string name, string source, string type, L2NormalizeTransformer parent)
            {
                if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}
				else if (type == typeof(TODO1).ToString())
				{
    				return new TODO2TypedColumn(name, source, parent);
				}

                throw new InvalidOperationException($"Column {name} has an unsupported type {type}.");
            }
        }

        internal abstract class TypedColumn<TSourceType, TOutputType> : TypedColumn
        {
            internal TypedColumn(string name, string source, string type) :
                base(name, source, type)
            {
            }

            internal abstract TOutputType Transform(TSourceType input);
            private protected abstract bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle);
            private protected abstract bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
            private protected abstract bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle);
            private protected abstract bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle);
            private protected abstract bool FitHelper(TransformerEstimatorSafeHandle estimator, TSourceType input, out FitResult fitResult, out IntPtr errorHandle);
            private protected abstract bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
            private protected abstract bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle);
            private protected TransformerEstimatorSafeHandle CreateTransformerFromEstimatorBase(IDataView input)
            {
                var success = CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle);
                if (!success)
                    throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                using (var estimatorHandle = new TransformerEstimatorSafeHandle(estimator, DestroyEstimatorHelper))
                {
                    if (!IsTrainingComplete(estimatorHandle))
                    {
                        var fitResult = FitResult.Continue;
                        while (fitResult != FitResult.Complete)
                        {
                            fitResult = FitResult.Continue;
                            using (var data = input.GetColumn<TSourceType>(Source).GetEnumerator())
                            {
                                while (fitResult == FitResult.Continue && data.MoveNext())
                                {
                                    {
                                        success = FitHelper(estimatorHandle, data.Current, out fitResult, out errorHandle);
                                        if (!success)
                                            throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));
                                    }
                                }

                                success = CompleteTrainingHelper(estimatorHandle, out fitResult, out errorHandle);
                                if (!success)
                                    throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));
                            }
                        }
                    }
                    success = CreateTransformerFromEstimatorHelper(estimatorHandle, out IntPtr transformer, out errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return new TransformerEstimatorSafeHandle(transformer, DestroyTransformerHelper);
                }
            }
        }

        #endregion
        
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
            #region TODO2TypedColumn

            internal sealed class TODO2TypedColumn : TypedColumn<TODO1, TODO1>
            {
                private TransformerEstimatorSafeHandle _transformerHandler;
                private L2NormalizeTransformer _parent;
                internal TODO2TypedColumn(string name, string source, L2NormalizeTransformer parent) :
                    base(name, source, typeof(TODO1).ToString())
                {
                    _parent = parent;
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateEstimatorNative(/* Codegen: Add additional parameters here */ out IntPtr estimator, out IntPtr errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyEstimatorNative(IntPtr estimator, out IntPtr errorHandle); // Should ONLY be called by safe handle

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromEstimator", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerFromEstimatorNative(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle);
                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_DestroyTransformer", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool DestroyTransformerNative(IntPtr transformer, out IntPtr errorHandle);
                internal override void CreateTransformerFromEstimator(IDataView input)
                {
                    _transformerHandler = CreateTransformerFromEstimatorBase(input);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerFromSavedData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool CreateTransformerFromSavedDataNative(byte* rawData, IntPtr bufferSize, out IntPtr transformer, out IntPtr errorHandle);
                private protected override unsafe void CreateTransformerFromSavedDataHelper(byte* rawData, IntPtr dataSize)
                {
                    var result = CreateTransformerFromSavedDataNative(rawData, dataSize, out IntPtr transformer, out IntPtr errorHandle);
                    if (!result)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    _transformerHandler = new TransformerEstimatorSafeHandle(transformer, DestroyTransformerNative);
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Transform", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool TransformDataNative(TransformerEstimatorSafeHandle transformer, TODO3: Parameter decl, TODO8: Parameter decl, out IntPtr errorHandle);
                TODO12: Delete transformed data
                internal unsafe override TODO1 Transform(TODO1 input)
                {
                    TODO5: Invocation statements
                    var success = TransformDataNative(_transformerHandler, interopInput, TODO8: Parameter decl, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    TODO10: Invocation statements
                    return output;
                    TODO6: Conversion end
                }

                public override void Dispose()
                {
                    if (!_transformerHandler.IsClosed)
                        _transformerHandler.Dispose();
                }

                private protected override bool CreateEstimatorHelper(out IntPtr estimator, out IntPtr errorHandle)
                {
                    /* Codegen: do any extra checks/paramters here */
                    return CreateEstimatorNative(out estimator, out errorHandle);
                }

                private protected override bool CreateTransformerFromEstimatorHelper(TransformerEstimatorSafeHandle estimator, out IntPtr transformer, out IntPtr errorHandle) =>
                    CreateTransformerFromEstimatorNative(estimator, out transformer, out errorHandle);

                private protected override bool DestroyEstimatorHelper(IntPtr estimator, out IntPtr errorHandle) =>
                    DestroyEstimatorNative(estimator, out errorHandle);

                private protected override bool DestroyTransformerHelper(IntPtr transformer, out IntPtr errorHandle) =>
                    DestroyTransformerNative(transformer, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_Fit", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static unsafe extern bool FitNative(TransformerEstimatorSafeHandle estimator, TODO3: Parameter decl, out FitResult fitResult, out IntPtr errorHandle);
                private protected unsafe override bool FitHelper(TransformerEstimatorSafeHandle estimator, TODO1 input, out FitResult fitResult, out IntPtr errorHandle)
                {
                    TODO5: Invocation statements
                    return FitNative(estimator, interopInput, out fitResult, out errorHandle);
                    TODO6: Conversion end
                }

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CompleteTraining", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CompleteTrainingNative(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle);
                private protected override bool CompleteTrainingHelper(TransformerEstimatorSafeHandle estimator, out FitResult fitResult, out IntPtr errorHandle) =>
                        CompleteTrainingNative(estimator, out fitResult, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_CreateTransformerSaveData", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool CreateTransformerSaveDataNative(TransformerEstimatorSafeHandle transformer, out IntPtr buffer, out IntPtr bufferSize, out IntPtr error);
                private protected override bool CreateTransformerSaveDataHelper(out IntPtr buffer, out IntPtr bufferSize, out IntPtr errorHandle) =>
                    CreateTransformerSaveDataNative(_transformerHandler, out buffer, out bufferSize, out errorHandle);

                [DllImport("Featurizers", EntryPoint = "L2NormalizeFeaturizer_re.compile('vector\\<(?P<type>\\S+)\\>')_IsTrainingComplete", CallingConvention = CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
                private static extern bool IsTrainingCompleteNative(TransformerEstimatorSafeHandle transformer, out bool isTrainingComplete, out IntPtr errorHandle);
                private protected override bool IsTrainingComplete(TransformerEstimatorSafeHandle estimatorHandle)
                {
                    var success = IsTrainingCompleteNative(estimatorHandle, out bool isTrainingComplete, out IntPtr errorHandle);
                    if (!success)
                        throw new Exception(GetErrorDetailsAndFreeNativeMemory(errorHandle));

                    return isTrainingComplete;
                }

                public override Type ReturnType()
                {
                    return typeof(TODO1);
                }
            }

            #endregion
            
        #endregion

        private sealed class Mapper : MapperBase
        {
            #region Class members

            private readonly L2NormalizeTransformer _parent;
            /* Codegen: add any extra class members here */

            #endregion

            public Mapper(L2NormalizeTransformer parent, DataViewSchema inputSchema) :
                base(parent.Host.Register(nameof(Mapper)), inputSchema, parent)
            {
                _parent = parent;
            }

            protected override DataViewSchema.DetachedColumn[] GetOutputColumnsCore()
            {
                return _parent._columns.Select(x => new DataViewSchema.DetachedColumn(x.Name, ColumnTypeExtensions.PrimitiveTypeFromType(x.ReturnType()))).ToArray();
            }

            private Delegate MakeGetter<TSourceType, TOutputType>(DataViewRow input, int iinfo)
            {
                ValueGetter<TOutputType> result = (ref TOutputType dst) =>
                {
                    var inputColumn = input.Schema[_parent._columns[iinfo].Source];
                    var srcGetterScalar = input.GetGetter<TSourceType>(inputColumn);

                    TSourceType value = default;
                    srcGetterScalar(ref value);

                    dst = ((TypedColumn<TSourceType, TOutputType>)_parent._columns[iinfo]).Transform(value);

                };

                return result;
            }

            protected override Delegate MakeGetter(DataViewRow input, int iinfo, Func<int, bool> activeOutput, out Action disposer)
            {
                disposer = null;
                Type inputType = input.Schema[_parent._columns[iinfo].Source].Type.RawType;
                Type outputType = _parent._columns[iinfo].ReturnType();

                return Utils.MarshalInvoke(MakeGetter<int, int>, new Type[] { inputType, outputType }, input, iinfo);
            }

            private protected override Func<int, bool> GetDependenciesCore(Func<int, bool> activeOutput)
            {
                var active = new bool[InputSchema.Count];
                for (int i = 0; i < InputSchema.Count; i++)
                {
                    if (_parent._columns.Any(x => x.Source == InputSchema[i].Name))
                    {
                        active[i] = true;
                    }
                }

                return col => active[col];
            }

            private protected override void SaveModel(ModelSaveContext ctx) => _parent.SaveModel(ctx);
        }
    }

    internal static class L2NormalizeEntrypoint
    {
        [TlcModule.EntryPoint(Name = "Transforms.L2Normalize",
            Desc = L2NormalizeTransformer.Summary,
            UserName = L2NormalizeTransformer.UserName,
            ShortName = L2NormalizeTransformer.ShortName)]
        public static CommonOutputs.TransformOutput L2Normalize(IHostEnvironment env, L2NormalizeEstimator.Options input)
        {
            var h = EntryPointUtils.CheckArgsAndCreateHost(env, L2NormalizeTransformer.ShortName, input);
            var xf = new L2NormalizeEstimator(h, input).Fit(input.Data).Transform(input.Data);
            return new CommonOutputs.TransformOutput()
            {
                Model = new TransformModelImpl(h, xf, input.Data),
                OutputData = xf
            };
        }
    }
}
